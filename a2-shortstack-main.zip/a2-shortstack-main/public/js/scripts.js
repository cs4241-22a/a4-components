// Add some Javascript code here, to run on the front end.

console.log("Welcome to assignment 2!")